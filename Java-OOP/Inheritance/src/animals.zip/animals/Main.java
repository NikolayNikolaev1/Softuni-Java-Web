package animals;

import animals.enums.AnimalType;
import animals.models.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static final String END_COMMAND = "Beast!";

    public static void main(String[] args) throws IOException {
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
        String animalTypeCommand = scanner.readLine();

        List<Animal> animals = new ArrayList<>();

        while (!END_COMMAND.equalsIgnoreCase(animalTypeCommand)) {
            Animal animal;
            AnimalType animalType = AnimalType.valueOf(animalTypeCommand.toUpperCase());
            String[] animalArgs = scanner.readLine().split("\\s+");
            String name = animalArgs[0];
            int age = Integer.parseInt(animalArgs[1]);
            String gender = animalArgs[2];

            try {
                switch (animalType) {
                    case DOG:
                        animal = new Dog(name, age, gender);
                        break;
                    case FROG:
                        animal = new Frog(name, age, gender);
                        break;
                    case CAT:
                        animal = new Cat(name, age, gender);
                        break;
                    case TOMCAT:
                        animal = new Tomcat(name, age, gender);
                        break;
                    case KITTEN:
                        animal = new Kitten(name, age, gender);
                        break;
                    default:
                        throw new IllegalArgumentException("Invalid input!");
                }

                animals.add(animal);
                animalTypeCommand = scanner.readLine();
            } catch (IllegalArgumentException exception) {
                System.out.println(exception.getMessage());
                animalTypeCommand = scanner.readLine();
            }
        }

        animals.forEach(a -> System.out.println(a.toString()));
    }
}
