package animals.enums;

public enum AnimalType {
    DOG,
    FROG,
    CAT,
    TOMCAT,
    KITTEN
}
