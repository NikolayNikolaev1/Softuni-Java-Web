package traffic.lights.enums;

public enum Signal {
    RED,
    GREEN,
    YELLOW
}
